<?php
include '../config.php';
$result = mysqli_query($conn,"SELECT * FROM bookings");
?>
<h1>Bookings Dashboard</h1>
<table border="1">
<tr><th>Name</th><th>Email</th><th>Room</th><th>Checkin</th><th>Status</th></tr>
<?php while($row = mysqli_fetch_assoc($result)) { ?>
<tr>
<td><?php echo $row['guest_name']; ?></td>
<td><?php echo $row['email']; ?></td>
<td><?php echo $row['room_id']; ?></td>
<td><?php echo $row['checkin']; ?></td>
<td><?php echo $row['payment_status']; ?></td>
</tr>
<?php } ?>
</table>