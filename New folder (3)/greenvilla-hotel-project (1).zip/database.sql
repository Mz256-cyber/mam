CREATE DATABASE greenvilla_db;
USE greenvilla_db;
CREATE TABLE rooms (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100),
    price INT,
    description TEXT
);
INSERT INTO rooms (name, price, description) VALUES
('Standard Room', 180000, 'Comfortable room with garden view'),
('Deluxe Room', 250000, 'Luxury room with balcony'),
('Family Suite', 400000, 'Two-bedroom family suite');
CREATE TABLE bookings (
    id INT AUTO_INCREMENT PRIMARY KEY,
    guest_name VARCHAR(150),
    email VARCHAR(150),
    phone VARCHAR(50),
    room_id INT,
    checkin DATE,
    checkout DATE,
    amount INT,
    payment_status VARCHAR(50) DEFAULT 'Pending',
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);