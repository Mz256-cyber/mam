<?php
include 'config.php';
$name = $_POST['guest_name'];
$email = $_POST['email'];
$phone = $_POST['phone'];
$room_id = $_POST['room_id'];
$checkin = $_POST['checkin'];
$checkout = $_POST['checkout'];
$room_query = mysqli_query($conn, "SELECT price FROM rooms WHERE id=$room_id");
$room = mysqli_fetch_assoc($room_query);
$amount = $room['price'];
mysqli_query($conn, "INSERT INTO bookings 
(guest_name,email,phone,room_id,checkin,checkout,amount)
VALUES ('$name','$email','$phone','$room_id','$checkin','$checkout','$amount')");
$booking_id = mysqli_insert_id($conn);
header("Location: payment.php?id=$booking_id");
?>