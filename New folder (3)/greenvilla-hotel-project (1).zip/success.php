<?php
include 'config.php';
$id = $_GET['id'];
mysqli_query($conn,"UPDATE bookings SET payment_status='Paid' WHERE id=$id");
echo "<h2>Payment Successful! Booking Confirmed.</h2>";
?>