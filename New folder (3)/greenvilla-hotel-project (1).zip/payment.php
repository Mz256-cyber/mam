<?php include 'config.php'; $id = $_GET['id']; ?>
<script src="https://checkout.flutterwave.com/v3.js"></script>
<button onclick="makePayment()">Pay Now</button>
<script>
function makePayment() {
FlutterwaveCheckout({
public_key: "YOUR_PUBLIC_KEY",
tx_ref: "greenvilla_"+Date.now(),
amount: 180000,
currency: "UGX",
payment_options: "mobilemoneyuganda,card"
});
}
</script>